namespace Accountant.Api.Settings
{
    public class AppSettings
    {
        public string AppEnv { get; set; }
    }
}