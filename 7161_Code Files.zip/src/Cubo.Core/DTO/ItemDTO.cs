using System;

namespace Cubo.Core.DTO
{
    public class ItemDTO
    {
        public string Key { get; set; }
        public string Value { get; set; }        
    }
}